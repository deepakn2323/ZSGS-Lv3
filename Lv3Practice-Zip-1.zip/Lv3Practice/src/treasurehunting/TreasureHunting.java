package treasurehunting;

import java.util.Scanner;

public class TreasureHunting {
    private static int dfs(int r, int c, int[][] dungeon,boolean[][]vis,int steps) {
        if(dungeon[r][c]==5){
            return steps;
        }
        if(vis[r][c]==true){
            return Integer.MAX_VALUE;
        }
        vis[r][c]=true;
        int min=Integer.MAX_VALUE;
        if(r<dungeon.length-1){
            int down=dfs(r+1,c,dungeon,vis,steps+1);
            min=Math.min(min,down);
        }
        if(c<dungeon[0].length-1){
            int right=dfs(r,c+1,dungeon,vis,steps+1);
            min=Math.min(min,right);
        }
        if(r>0){
            int up=dfs(r-1,c,dungeon,vis,steps+1);
            min=Math.min(up,min);
        }
        if(c>0){
            int left=dfs(r,c-1,dungeon,vis,steps+1);
            min=Math.min(left,min);
        }
        vis[r][c]=false;
        return min;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n=5;
        int m=4;
        int[][]dungeon=new int[n][m];
        int goldLocationRow=scanner.nextInt()-1;
        int goldLocationCol=scanner.nextInt()-1;
        int adventurerLocationRow=scanner.nextInt()-1;
        int adventurerLocationCol= scanner.nextInt()-1;
        dungeon[goldLocationRow][goldLocationCol]=5;
        boolean[][]vis=new boolean[n][m];
        int minSteps=dfs(adventurerLocationRow,adventurerLocationCol,dungeon,vis,0);
        System.out.println("Min Steps : "+minSteps);
    }


}
