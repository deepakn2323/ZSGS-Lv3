package treasurehunting;

import java.util.Arrays;
import java.util.Scanner;

public class TreasureHunting {
    int minPath=Integer.MAX_VALUE;
    private void dfs(int r, int c, int[][] dungeon,boolean[][]vis,int steps,int[][]directions) {
        if(dungeon[r][c]==5){
            minPath=Math.min(minPath,steps);
            return;
        }
        if(vis[r][c]){
            return;
        }
        if(dungeon[r][c]==-1){
            return;
        }
        vis[r][c]=true;
        for(int[] dir : directions){
            int nRow=r+dir[0];
            int nCol=c+dir[1];
            if(nRow>=0&&nCol>=0&&nRow<dungeon.length&&nCol<dungeon[0].length&& !vis[nRow][nCol]){
                dfs(nRow,nCol,dungeon,vis,steps+1,directions);
            }
        }
        vis[r][c]=false;
    }
    public static void main(String[] args) {
        TreasureHunting treasureHunting=new TreasureHunting();
        Scanner scanner = new Scanner(System.in);
        int n=5;
        int m=4;
        int[][]dungeon=new int[n][m];

        System.out.println("Enter Adventurer Position Row and Col");
        int adventurerLocationRow=scanner.nextInt()-1;
        int adventurerLocationCol= scanner.nextInt()-1;

        System.out.println("Enter Gold Position Row and Col");
        int goldLocationRow=scanner.nextInt()-1;
        int goldLocationCol=scanner.nextInt()-1;

        System.out.println("Enter numer of pits : ");
        int pits=scanner.nextInt();
        for(int i=1;i<=pits;i++){
            System.out.println("Enter Pits Position Row and Col ");
            dungeon[scanner.nextInt()-1][scanner.nextInt()-1]=-1;
        }
        dungeon[goldLocationRow][goldLocationCol]=5;
        int[][]directions={{0,1},{1,0},{-1,0},{0,-1}};
        boolean[][]vis=new boolean[n][m];
        treasureHunting.dfs(adventurerLocationRow,adventurerLocationCol,dungeon,vis,0,directions);
        System.out.println(treasureHunting.minPath==Integer.MAX_VALUE?"No Possible Solution":"Minimum Steps : "+treasureHunting.minPath);
    }


}
