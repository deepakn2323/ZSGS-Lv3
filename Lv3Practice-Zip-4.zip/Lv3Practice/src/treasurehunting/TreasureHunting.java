package treasurehunting;

import java.util.Scanner;

public class TreasureHunting {
    private static int dfs(int r, int c,int rG,int cG, int[][] dungeon,boolean[][]vis,int steps,int[][]directions) {
        if(r==rG&&c==cG){
            return steps;
        }
        if(vis[r][c]==true){
            return Integer.MAX_VALUE;
        }
        vis[r][c]=true;
        int min=Integer.MAX_VALUE;
        for(int[] dir : directions){
            int nRow=r+dir[0];
            int nCol=c+dir[1];
            if(nRow>=0&&nCol>=0&&nRow<dungeon.length&&nCol<dungeon[0].length&&vis[nRow][nCol]==false){
                min=Math.min(min,dfs(nRow,nCol,rG,cG,dungeon,vis,steps+1,directions));

            }
        }
        vis[r][c]=false;
        return min;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n=5;
        int m=4;
        int[][]dungeon=new int[n][m];


        System.out.println("Enter Adventurer Position Row and Col");
        int adventurerLocationRow=scanner.nextInt()-1;
        int adventurerLocationCol= scanner.nextInt()-1;

        System.out.println("Enter Monster Position Row and Col");
        int monsterLocationRow=scanner.nextInt()-1;
        int monsterLocationCol=scanner.nextInt()-1;

        System.out.println("Enter Trigger Position Row and Col");
        int triggerLocationRow=scanner.nextInt()-1;
        int triggerLocationCol=scanner.nextInt()-1;

        System.out.println("Enter Gold Position Row and Col");
        int goldLocationRow=scanner.nextInt()-1;
        int goldLocationCol=scanner.nextInt()-1;

        int[][]directions={{0,1},{1,0},{-1,0},{0,-1}};
        boolean[][]vis=new boolean[n][m];
        int minStepsForAdventurer=dfs(adventurerLocationRow,adventurerLocationCol,goldLocationRow,goldLocationCol,dungeon,vis,0,directions);
        int minStepsForMonster=dfs(monsterLocationRow,monsterLocationCol,goldLocationRow,goldLocationCol,dungeon,vis,0,directions);
        int diff=minStepsForMonster-minStepsForAdventurer;
        int minStepsToTrigger=0;
        int minStepsToGoldFromTrigger=0;
        if(diff<0){
            minStepsToTrigger=dfs(adventurerLocationRow,adventurerLocationCol,triggerLocationRow,triggerLocationCol,dungeon,vis,0,directions);
            minStepsToGoldFromTrigger=dfs(triggerLocationRow,triggerLocationCol,goldLocationRow,goldLocationCol,dungeon,vis,0,directions);
            System.out.println("Minimum number of steps : "+(minStepsToTrigger+minStepsToGoldFromTrigger));
        }else{
            System.out.println("Minimum number of steps : "+minStepsForAdventurer);
        }
    }


}
